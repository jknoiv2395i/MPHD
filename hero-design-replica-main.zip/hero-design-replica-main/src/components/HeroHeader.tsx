import { FigmaNavBar } from "@/components/ui/figma-navbar";

const HeroHeader = () => {
  return <FigmaNavBar />;
};
export default HeroHeader;
